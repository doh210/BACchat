/**
 * Copyright 2016 IBM Corp. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
'use strict';
var selectModel = require('./views/selectmodel').initSelectModel;

exports.getModels = function(token) {
  var viewContext = {
    currentModel: 'en-US_BroadbandModel',
    models: null,
    token: token,
    bufferSize: BUFFERSIZE
  };
  var modelUrl = 'https://stream.watsonplatform.net/speech-to-text/api/v1/models';
  var sttRequest = new XMLHttpRequest();
  sttRequest.open('GET', modelUrl, true);
  sttRequest.withCredentials = true;
  sttRequest.setRequestHeader('Accept', 'application/json');
  sttRequest.setRequestHeader('X-Watson-Authorization-Token', token);
  sttRequest.onload = function() {
    var response = JSON.parse(sttRequest.responseText);
    var sorted = response.models.sort(function(a,b) {
    if(a.name > b.name) {
      return 1;
    }
    if( a.name < b.name) {
      return -1;
    }
    return 0;
    });
    response.models=sorted;
    localStorage.setItem('models', JSON.stringify(response.models));
    viewContext.models = response.models;
    selectModel(viewContext);
  };
  sttRequest.onerror = function() {
    viewContext.models = require('./data/models.json').models;
    selectModel(viewContext);
  };
  sttRequest.send();
};
